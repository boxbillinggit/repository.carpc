#!/usr/bin/env python

import xbmc
import xbmcgui

class MyPlayer(xbmc.Player):

	def __init__ (self):
		xbmc.Player.__init__(self)

	def onQueueNextItem(self):
		xbmc.executebuiltin("Notification(Next,,250)")

	def onPlayBackStarted(self):
		xbmc.executebuiltin("Notification(Started,,250)")
				
	def onPlayBackEnded(self):
		xbmc.executebuiltin("Notification(Ended,,250)")
				
	def onPlayBackStopped(self):
		xbmc.executebuiltin("Notification(Stopped,,250)")
				
	def onPlayBackPaused(self):
		xbmc.executebuiltin("Notification(Pause,,250)")

	def onPlayBackResumed(self):
		xbmc.executebuiltin("Notification(Resumed,,250)")

	def onPlayBackSeek(self, time, seekOffset):
		xbmc.executebuiltin("Notification(Seek," + str(time) + ",250)")


class MyMonitor(xbmc.Monitor):

	def __init__ (self):
		xbmc.Monitor.__init__(self)

	def onAbortRequested(self):
		global bCloseScript
		bCloseScript = True


########## -- programm -- ##########
if xbmc.getSkinDir() == 'skin.confluence-vertical-beta':
	bCloseScript = False
else:
	bCloseScript = True

player = MyPlayer()
monitor = MyMonitor()
iLoopCount = 0

while not ( bCloseScript ):
	if iLoopCount == 10: 
		xbmc.sleep(100)
		iLoopCount = 0

	iLoopCount += 1

pass