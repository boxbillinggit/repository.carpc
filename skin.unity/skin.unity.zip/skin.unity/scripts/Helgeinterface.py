#!/usr/bin/env python

#Name: HelgeInterface
#Version: v0.1
#Owner: harryberlin

import sys, urllib
import xbmc, xbmcgui, xbmcaddon

#bDEBUG = False

HI_CLASS = ['OBC', 'IKE', 'IBUS']
HI_METHOD_OBC = ['Refresh', 'Reset', 'Set']
HI_METHOD_IKE = ['DisplayText']
HI_METHOD_IBUS = ['SendMsg']
HI_METHOD = [HI_METHOD_OBC, HI_METHOD_IKE, HI_METHOD_IBUS]


#######################  -- Functions -- #######################
def debug(sText1,sText2='',sText3=''):
	try:
		if bDEBUG: xbmcgui.Dialog().ok(str(sText1), str(sText2), str(sText3))
	except:
		return


def hi_json( sClass, sMethod, sProperty ):
	
	debug("got JSON arguments", sMethod, sProperty)
	
	ip = '127.0.0.1'
	port = '44000'
	sClass_tmp = str(sClass)
	sMethod_tmp = str(sMethod)
	sClassMethod_tmp = sClass_tmp + '.' + sMethod_tmp
	sProperty_tmp = str(sProperty)
	
	# replace , for multi request
	debug('before', sProperty_tmp)
	if sMethod in [HI_METHOD_OBC[0],HI_METHOD_OBC[1]]: sProperty_tmp = sProperty_tmp.replace(',', ', "Property": ')
	debug('after', sProperty_tmp)

	try:
		urllib.urlopen('http://' + ip + ':' + port + '/jsonrpc?request={"jsonrpc": "2.0", "method": "' + sClassMethod_tmp + '", "params": { "Property": ' + sProperty_tmp + ' }, "id": 0}', [0])
	except:
		return


#####################  -- programm -- #####################

#debug('',xbmcaddon.Addon(xbmc.getSkinDir()).getAddonInfo('path').decode('utf-8'))

busybox = xbmcgui.WindowXMLDialog('DialogBusy.xml', xbmcaddon.Addon(xbmc.getSkinDir()).getAddonInfo('path').decode('utf-8'), 'default', '720p')
busybox.show()

count = len(sys.argv) - 1
 
if count < 1:
	debug("No arguments given", "You must specify arguments to the script", "i.e. 'tether_toggle' - to toggle wifi tethering, etc")
else:
	aMethod = str(sys.argv[1]).split(".")
	
	# parse Class and set Index
	if aMethod[0] in HI_CLASS:
		iHI_CLASS_INDEX = int(HI_CLASS.index(aMethod[0]))
		debug("", "CLASS is OK ", aMethod[0])
	else:
		debug("unknown arguments given", " - ".join(sys.argv))
		pass

	# parse Method and set Index
	if aMethod[1] in HI_METHOD[iHI_CLASS_INDEX]:
		iHI_METHOD_INDEX = int(HI_METHOD[iHI_CLASS_INDEX].index(aMethod[1]))
		
		debug("good parameter given", ".".join(aMethod), sys.argv[2])
	else:
		debug("combined arguments bad", "don't combine Class   -   Method" , str(aMethod[0]) + " - " + str(aMethod[1]))
		pass	
	
	# send as json
	hi_json(aMethod[0], aMethod[1], sys.argv[2])

xbmc.sleep(1000)
busybox.close()
del busybox

pass
