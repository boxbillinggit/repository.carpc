#!/usr/bin/env python

#Name: BMWRaspControl HelgeIntefaceUpdater
#Version: v0.4
#Owner: Horst12345
#2015/09/03 changed for HelegInerface by The Mischen

import urllib,os,re,urllib2,glob,shutil,time, zipfile
import xbmc,xbmcgui,xbmcaddon

def DownloaderClass(url,dest):
    dp = xbmcgui.DialogProgress()
    dp.create("BMWRaspControl Update","Lade Datei", "BMW RaspControl HelgeInterface - Update")
    urllib.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))

def _pbhook(numblocks, blocksize, filesize, url=None,dp=None):
    try:
        percent = min((numblocks*blocksize*100)/filesize, 100)
        print percent
        dp.update(percent)
    except:
        percent = 100
        dp.update(percent)
    if dp.iscanceled(): 
        print "Download Abgebrochen"
        dp.close()		
	quit()
	
def CheckFolders(directory):
    if not os.path.exists(directory):
	os.makedirs(directory)
    
def BackUp():
    backUpDir = "/home/HelgeInterface/Update/BackUp/" + time.strftime("%Y%m%d_%H:%M:%S")
    files = glob.iglob(os.path.join("/home/HelgeInterface", "*elge*nterface*.*"))
    CheckFolders(backUpDir)
    for file in files:
        if os.path.isfile(file):
            shutil.copy2(file, backUpDir)

    action = "Notification(HelgeInterface Updater,Create BackUp to: " + backUpDir + " ,7000)"
    xbmc.executebuiltin(action)


def Install(file, dst):
    zip = zipfile.ZipFile(file, "r")
    for file in zip.namelist():
	if ("dll" not in file) and ("exe" not in file):
	    continue
	print("copy  "+ file + " to " + dst)
        zip.extract(file, dst)

def checkinternet():
    try:
        response=urllib2.urlopen('http://173.194.32.223',timeout=2)
        return True
    except urllib2.URLError as err: pass
    return False

dialog = xbmcgui.Dialog()
if dialog.yesno("BMW RaspControl HelgeInterfaceupdater", "Are you sure to update HelgeInterface?") == 1:
    if checkinternet() == 1:
            newFile = "/home/HelgeInterface/Update/HelgeInterface.zip"
	    CheckFolders("/home/HelgeInterface/Update/BackUp")
            url ='http://bmwraspcontrol.de/software/HelgeInterface_last.zip'
	    if dialog.yesno("BMW RaspControl HelgeInterfaceupdater", "Do you want to update Beta?") == 1:
	        url ='http://bmwraspcontrol.de/software/HelgeInterface_BETA.zip'
            BackUp()
            DownloaderClass(url,newFile)
	    Install(newFile, "/home/")
            os.system('sudo service HelgeInterface restart')
            xbmc.sleep(7000)
	    busybox = xbmcgui.WindowXMLDialog('DialogBusy.xml', xbmcaddon.Addon(xbmc.getSkinDir()).getAddonInfo('path').decode('utf-8'), 'default', '720p')
	    busybox.show()
            xbmc.sleep(10000)
	    busybox.close()
	    del busybox
            xbmc.executebuiltin("Notification(Update successfull, You may have to reactivate BMWRaspControl by pressing 'Mode' ,10000)")

    else:
            xbmc.executebuiltin("Notification(BMWRaspControl HelgeInterface Updater,VERBINDUNGSFEHLER!,500)")

#dialog.ok("BMW RaspControl Updater","HelgeInterface[CR]","HelgeInterface Update is not working yet.")

pass
